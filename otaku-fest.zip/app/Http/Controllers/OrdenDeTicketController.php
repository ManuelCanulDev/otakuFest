<?php

namespace App\Http\Controllers;

use App\Mail\BoletosAcreditados;
use App\Mail\BoletosPrePagados;
use App\Mail\EmergencyCallReceived;
use App\Mail\NotificacionOtakuFest;
use App\Models\OrdenDeTicket;
use App\Models\Ticket;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;

/**
 * Class OrdenDeTicketController
 * @package App\Http\Controllers
 */
class OrdenDeTicketController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $ordenDeTickets = OrdenDeTicket::paginate();

        return view('orden-de-ticket.index', compact('ordenDeTickets'))
            ->with('i', (request()->input('page', 1) - 1) * $ordenDeTickets->perPage());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $ordenDeTicket = new OrdenDeTicket();
        return view('orden-de-ticket.create', compact('ordenDeTicket'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(OrdenDeTicket::$rules);

        $ordenDeTicket = OrdenDeTicket::create($request->all());

        return redirect()->route('orden-de-tickets.index')
            ->with('success', 'OrdenDeTicket created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $ordenDeTicket = OrdenDeTicket::find($id);

        return view('orden-de-ticket.show', compact('ordenDeTicket'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $ordenDeTicket = OrdenDeTicket::find($id);

        return view('orden-de-ticket.edit', compact('ordenDeTicket'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  OrdenDeTicket $ordenDeTicket
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, OrdenDeTicket $ordenDeTicket)
    {
        request()->validate(OrdenDeTicket::$rules);

        $ordenDeTicket->update($request->all());

        return redirect()->route('orden-de-tickets.index')
            ->with('success', 'OrdenDeTicket updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $ordenDeTicket = OrdenDeTicket::find($id)->delete();

        return redirect()->route('orden-de-tickets.index')
            ->with('success', 'OrdenDeTicket deleted successfully');
    }

    public function verMisOrdenes()
    {
        $ordenes = OrdenDeTicket::where([['user_id', '=', Auth::user()->id]])->get();
        return view('verMisOrdenes', compact('ordenes'));
    }

    public function prueba()
    {
        //$orden = OrdenDeTicket::find(rand(1,2));
        //return view('prueba');
        //Mail::to("jafet.ramsell@gmail.com")->send(new BoletosPrePagados("UID_VM9nL3D19B4"));
        //Mail::to('manuelcanuldev@gmail.com')->send(new NotificacionOtakuFest('Manuel','ESTO ES UN MENSAJE DE PRUEBA',''));
    }

    public function reenviarCorreoOrden($uid = null)
    {
        if ($uid != null) {
            $ordenTicket = OrdenDeTicket::where([['uid', '=', $uid]])->get();
            Mail::to($ordenTicket[0]->correo_orden)->send(new BoletosPrePagados($uid, $ordenTicket[0]->costo_total_orden));
            return redirect('/gracias-por-tu-compra/' . $uid);
        } else {
            return redirect('home');
        }
    }

    public function asignarBoletos($uid = null)
    {
        $orden = OrdenDeTicket::where('uid', $uid)->firstOrFail();

        return view('asignar-boletos', compact('orden'));
    }

    public function superAsignarBoletos(Request $request)
    {
        $ticket = Ticket::find($request->ticket_id);


        $ticket->nombres = $request->nombres;
        $ticket->apellidos = $request->apellidos;
        $ticket->telefono = $request->telefono;
        $ticket->correo = $request->correo;

        if ($ticket->type_ticket_id == 1) {
            $ticket->fecha_asistencia = $request->fecha_asistencia;
        }

        $ticket->save();

        return redirect('asignar-boletos/' . $request->order_uid);
    }

    public function superAsignarBoletosOnlyFechaAsistencia(Request $request)
    {
        $ticket = Ticket::find($request->ticket_id);


        $ticket->fecha_asistencia = $request->fecha_asistencia;
        $ticket->save();

        return redirect('asignar-boletos/' . $request->order_uid);
    }

    public function acreditarBoletosAjax(Request $request)
    {
        $orden = OrdenDeTicket::where('uid', $request->uid)->firstOrFail();

        $orden->pagado = "SI";

        $orden->save();

        foreach ($orden->tickets as $llave => $ticket) {
            $ticket = Ticket::find($ticket->id);

            $ticket->pagado = true;
            $ticket->status = "A";
            $ticket->save();
        }

        Mail::to($orden->correo_orden)->send(new BoletosAcreditados($request->uid));

        return redirect('orden-de-tickets');
    }

    public function desAcreditarBoletosAjax(Request $request)
    {
        $orden = OrdenDeTicket::where('uid', $request->uid)->firstOrFail();

        $orden->pagado = "NO";

        $orden->save();

        foreach ($orden->tickets as $llave => $ticket) {
            $ticket = Ticket::find($ticket->id);

            $ticket->pagado = false;
            $ticket->status = "D";
            $ticket->save();
        }

        return redirect('orden-de-tickets');
    }

    public function enviarNotificaciones(Request $request)
    {
        $oks = 0;
        $bads = 0;

        if ($request->grupo == "T") {
            $usuarios = User::all();

            foreach ($usuarios as $llave => $valor) {
                try {
                    Mail::to($valor->email)->send(new NotificacionOtakuFest(strtoupper($valor->name), $request->mensaje, $request->url));
                    $oks++;
                } catch (\Exception $th) {
                    $bads++;
                }
            }
        } else {
            $usuariosParametrizados = Ticket::select('user_id')->where([['type_ticket_id','=',$request->grupo],['status','=','A']])->get()->groupBy('user_id');

            //dd($usuariosParametrizados);

            foreach ($usuariosParametrizados as $llave => $valore) {
                echo $llave."<br>";
                $usuario = User::find($llave);

                try {
                    Mail::to($usuario->email)->send(new NotificacionOtakuFest(strtoupper($usuario->name), $request->mensaje, $request->url));
                    $oks++;
                } catch (\Exception $th) {
                    $bads++;
                }
            }
        }

        return Redirect::back()->withErrors(['msg' => 'Se han enviado: '.$oks.' notificaciones y han fallado en enviar: '.$bads]);
    }
}
